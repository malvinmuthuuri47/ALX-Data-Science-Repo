"""
This module contains code that initializes weather station data
using a class by reading the data from a remote csv file and
placing the data in a Pandas DataFrame
"""
import re
import numpy as np
import pandas as pd
import logging
from data_ingestion import read_from_web_CSV

class WeatherDataProcessor:
    def __init__(self, config_params, logging_level="INFO"):
        self.weather_station_data = config_params['weather_csv_path']
        self.patterns = config_params['regex_patterns']
        self.weather_df = None
        self.initialize_logging(logging_level)
    
    def initialize_logging(self, logging_level):
        """
        Initializes and sets the logging level for the logger
        used in by the class instances

        Parameters:
            logging_level: Sets the logging level
        """
        logger_name = __name__ + ".WeatherDataProcessor"
        self.logger = logging.getLogger(logger_name)
        self.logger.propagate = False
        
        if logging_level.upper() == "DEBUG":
            log_level = logging.DEBUG
        elif logging_level.upper() == "INFO":
            log_level = logging.INFO
        elif logging_level.upper() == "NONE":
            self.logger.disabled = True
        else:
            log_level = logging.INFO
        
        self.logger.setLevel(log_level)
        
        if not self.logger.handlers:
            ch = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            ch.setFormatter(formatter)
            self.logger.addHandler(ch)
    
    def weather_station_mapping(self):
        """
        Reads data from a remote CSV file and initializes the weather dataframe
        with the content from the remote CSV file
        """
        self.weather_df = read_from_web_CSV(self.weather_station_data)
        self.logger.info("Successfully loaded weather station data from the web")
        # Here, you can apply any initial transformations to self.weather_df if necessary
        
    def extract_measurement(self, message):
        """
        Uses the regex patterns in the patterns dictionary to extract the
        measurements and returns both the measurement type matched by the
        regex and the value

        Parameters:
            message: The string of text to be matched by the regex
        
        Returns:
            The Measurement type and the value, None otherwise
        """
        for key, pattern in self.patterns.items():
            match = re.search(pattern, message)
            if match:
                self.logger.debug(f"Measurement extracted: {key}")
                return key, float(next((x for x in match.groups() if x is not None)))
        self.logger.debug("No measurement match found.")
        return None, None
    
    def process_message(self):
        """
        Unpacks the measurement and value into separate variables which are then
        used to populate two dataframe columns and returns the updated dataframe

        Returns:
            Updated dataframe
        """
        if self.weather_df is not None:
            result = self.weather_df['Message'].apply(self.extract_measurement)
            self.weather_df['Measurement'], self.weather_df['Value'] = zip(*result)
            self.logger.info("Messages processed and measurements extracted.")
        else:
            self.logger.warning("weather_df is not initialized, skipping message processing.")
        return self.weather_df
    
    def calculate_means(self):
        """
        Calculates the mean for the grouped data and returns the unstacked mean

        Returns:
            unstacked mean values in the dataframe
        """
        if self.weather_df is not None:
            means = self.weather_df.groupby(by=['Weather_station_ID', 'Measurement'])['Value'].mean()
            self.logger.info("Mean values calculated.")
            return means.unstack()
        else:
            self.logger.warning("weather_df is not initialized, cannot calculate means.")
            return None
    
    def process(self):
        """
        Calls the defined methods above
        """
        self.weather_station_mapping()
        self.process_message()
        self.logger.info("Data processing completed.")
