"""
This module creates a class that imports functions to connect and query a SQLite3 database
and read content from a remote CSV file while also creating logs as operations take place
in the data pipeline
"""

import pandas as pd
from data_ingestion import create_db_engine, query_data, read_from_web_CSV
import logging

class FieldDataProcessor:
	"""
	Load, clean, and merge agricultural field data
	"""
	def __init__(self, config_params, logging_level="INFO"):  # When we instantiate this class,
		"""
		This method initializes the class instances with the values for the keys found in
		the config_params dictionary.

		Parameters:
			config_params: A dictionary containing all the configuration paths for the data
			logging_level: A parameter that indicates what level of logging should be shown
						   to the user
		"""
		# we can optionally specify what logs we want to see
        # initialising class with attributes we need. Refer to the code above to understand how
		# each attribute relates to the code
		self.db_path = config_params['db_path']
		self.sql_query = config_params['sql_query']
		self.columns_to_rename = config_params['columns_to_rename']
		self.values_to_rename = config_params['values_to_rename']
		self.weather_map_data = config_params['weather_mapping_csv']

		self.initialize_logging(logging_level)
        
        # We create empty objects to store the DataFrame and engine in
		self.df = None
		self.engine = None
    
    # This method enables logging in the class
	def initialize_logging(self, logging_level):
		"""Sets up Logging for this instance of FieldDataProcessor"""
		logger_name = __name__ + ".FieldDataProcessor"
		self.logger = logging.getLogger(logger_name)
		self.logger.propagate = False  # Prevents log messages from being propagated to the root logger
        
        # Set logging level
		if logging_level.upper() == "DEBUG":
			log_level = logging.DEBUG
		elif logging_level.upper() == "INFO":
			log_level = logging.INFO
		elif logging_level.upper() == "NONE":  # Option to disable logging
			self.logger.disabled = True
			return
		else:
			log_level = logging.INFO  # Default to INFO

		self.logger.setLevel(log_level)
        
        # Only add handler if not already added to avoid duplicate messages
		if not self.logger.handlers:
			ch = logging.StreamHandler()  # Create console handler
			formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
			ch.setFormatter(formatter)
			self.logger.addHandler(ch)
        
        # Use self.logger.info(), self.logger.debug(), etc.
    
    # DataFrame methods
	def ingest_sql_data(self):
		"""
		Connects to the Database, queries it using the provided SQL query, logs the message,
		and returns the updated dataframe
		"""
		self.engine = create_db_engine(self.db_path)
		self.df = query_data(self.engine, self.sql_query)
		self.logger.info("Successfully loaded data.")
		return self.df
            
	def rename_columns(self):
		"""
		Takes the Dataframe and renames the columns to match the correct datatypes
		while returning the updated renamed columns dataframe
		"""
        # Extract the columns to rename from the configuration
		column1, column2 = list(self.columns_to_rename.keys())[0], list(self.columns_to_rename.values())[0]
        
        # Temporarily rename one of the columns to avoid a naming conflict
		temp_name = "__temp_name_for_swap__"
		while temp_name in self.df.columns:
			temp_name += "_"

		self.logger.info(f"Swapped columns: {column1} with {column2}")
        
        # Perform the swap
		self.df = self.df.rename(columns={column1: temp_name, column2: column1})
		self.df = self.df.rename(columns={temp_name: column2})
		return self.df
    
	def apply_corrections(self, column_name='Crop_type', abs_column='Elevation'):
		"""
		Applies the absolute() method to a column of the dataframe to make the column values correct
		while returning the updated dataframe
		"""
		self.df[abs_column] = self.df[abs_column].abs()
		self.df[column_name] = self.df[column_name].apply(lambda crop: self.values_to_rename.get(crop, crop))
		return self.df
    
	def weather_station_mapping(self):
		"""
		Fetches data mapping the field data to the nearest weather station and then merges it on the Field_ID,
		returning the updated DataFrame
		"""
		weather_map_df = read_from_web_CSV(self.weather_map_data)
		self.df = self.df.merge(weather_map_df, on='Field_ID', how='left')
		return self.df
    
	def process(self):
		"""
		Calls all the methods defined above and returns the resulting dataframe after it has been processed by
		each function
		"""
        # This process calls the correct methods and applies the changes, step by step. This is the method we will
		# call, and it will call the other methods in order
		self.df = self.ingest_sql_data()
		self.df = self.rename_columns()
		self.df = self.apply_corrections()
		self.df = self.weather_station_mapping()
		return self.df
